import React, { useState, useContext, useMemo } from 'react';
import { ComplaintContext } from '../context/ComplaintContext';
import ComplaintCard from './ComplaintCard';

const AdminDashboard = ({ user, onLogout }) => {
  const { complaints, updateComplaintStatus } = useContext(ComplaintContext);
  const [filterStatus, setFilterStatus] = useState('All');
  const [filterCategory, setFilterCategory] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');

  // Get unique categories
  const categories = useMemo(() => {
    const cats = new Set(complaints.map((c) => c.category));
    return ['All', ...Array.from(cats)];
  }, [complaints]);

  // Filter complaints
  const filteredComplaints = useMemo(() => {
    return complaints.filter((complaint) => {
      const statusMatch =
        filterStatus === 'All' || complaint.status === filterStatus;
      const categoryMatch =
        filterCategory === 'All' || complaint.category === filterCategory;
      const searchMatch =
        searchTerm === '' ||
        complaint.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (complaint.title && complaint.title.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (complaint.location && complaint.location.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (complaint.userName && complaint.userName.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (complaint.studentName && complaint.studentName.toLowerCase().includes(searchTerm.toLowerCase()));

      return statusMatch && categoryMatch && searchMatch;
    });
  }, [complaints, filterStatus, filterCategory, searchTerm]);

  // Statistics
  const stats = useMemo(() => {
    return {
      total: complaints.length,
      pending: complaints.filter((c) => c.status === 'Pending').length,
      inProgress: complaints.filter((c) => c.status === 'In Progress').length,
      resolved: complaints.filter((c) => c.status === 'Resolved').length,
    };
  }, [complaints]);

  const handleStatusChange = async (complaintId, newStatus, adminResponse = '') => {
    try {
      await updateComplaintStatus(complaintId, newStatus, adminResponse);
    } catch (error) {
      console.error('Error updating complaint status:', error);
    }
  };

  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <div>
          <h1>Admin Dashboard</h1>
          <p>Welcome, Admin {user.username}!</p>
        </div>
        <button className="logout-btn" onClick={onLogout}>
          Logout
        </button>
      </div>

      <div className="dashboard-content">
        {/* Statistics */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
            gap: '15px',
            marginBottom: '30px',
          }}
        >
          <div
            style={{
              background: 'linear-gradient(135deg, #FF9F5A 0%, #FF8C42 100%)',
              color: 'white',
              padding: '20px',
              borderRadius: '8px',
              textAlign: 'center',
            }}
          >
            <h3 style={{ fontSize: '32px', marginBottom: '5px' }}>
              {stats.total}
            </h3>
            <p style={{ fontSize: '14px', opacity: 0.9 }}>Total Complaints</p>
          </div>
          <div
            style={{
              background: 'linear-gradient(135deg, #FFB88C 0%, #FFA87D 100%)',
              color: 'white',
              padding: '20px',
              borderRadius: '8px',
              textAlign: 'center',
            }}
          >
            <h3 style={{ fontSize: '32px', marginBottom: '5px' }}>
              {stats.pending}
            </h3>
            <p style={{ fontSize: '14px', opacity: 0.9 }}>Pending</p>
          </div>
          <div
            style={{
              background: 'linear-gradient(135deg, #FFD4A8 0%, #FFC899 100%)',
              color: '#333',
              padding: '20px',
              borderRadius: '8px',
              textAlign: 'center',
            }}
          >
            <h3 style={{ fontSize: '32px', marginBottom: '5px' }}>
              {stats.inProgress}
            </h3>
            <p style={{ fontSize: '14px', opacity: 0.9 }}>In Progress</p>
          </div>
          <div
            style={{
              background: 'linear-gradient(135deg, #FFEAD4 0%, #FFDFC7 100%)',
              color: '#333',
              padding: '20px',
              borderRadius: '8px',
              textAlign: 'center',
            }}
          >
            <h3 style={{ fontSize: '32px', marginBottom: '5px' }}>
              {stats.resolved}
            </h3>
            <p style={{ fontSize: '14px', opacity: 0.9 }}>Resolved</p>
          </div>
        </div>

        {/* Filters */}
        <div className="filters">
          <div className="filter-group">
            <label htmlFor="statusFilter">Status</label>
            <select
              id="statusFilter"
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
            >
              <option>All</option>
              <option>Pending</option>
              <option>In Progress</option>
              <option>Resolved</option>
            </select>
          </div>

          <div className="filter-group">
            <label htmlFor="categoryFilter">Category</label>
            <select
              id="categoryFilter"
              value={filterCategory}
              onChange={(e) => setFilterCategory(e.target.value)}
            >
              {categories.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          <div className="filter-group">
            <label htmlFor="searchInput">Search</label>
            <input
              id="searchInput"
              type="text"
              placeholder="Location, student name, description..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>

        {/* Complaints List */}
        <h2 style={{ marginBottom: '20px', color: '#333' }}>
          All Complaints ({filteredComplaints.length})
        </h2>
        {filteredComplaints.length === 0 ? (
          <div className="empty-state">
            <h3>No complaints found</h3>
            <p>Try adjusting your filters</p>
          </div>
        ) : (
          <div className="complaints-container">
            {filteredComplaints
              .sort((a, b) => {
                // Sort by upvotes first, then by creation date
                if (b.upvotes !== a.upvotes) {
                  return b.upvotes - a.upvotes;
                }
                return new Date(b.createdAt) - new Date(a.createdAt);
              })
              .map((complaint) => (
                <ComplaintCard
                  key={complaint._id}
                  complaint={complaint}
                  isAdmin={true}
                  onStatusChange={(newStatus, adminResponse) =>
                    handleStatusChange(complaint._id, newStatus, adminResponse)
                  }
                />
              ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;
