import React, { useState, useContext, useEffect } from 'react';
import { ComplaintContext } from '../context/ComplaintContext';
import ComplaintForm from './ComplaintForm';
import ComplaintCard from './ComplaintCard';

const StudentDashboard = ({ user, onLogout }) => {
  const { complaints, loading, upvoteComplaint, getComplaintsByStudent } = useContext(ComplaintContext);
  const [activeTab, setActiveTab] = useState('submit');
  const [successMessage, setSuccessMessage] = useState('');
  const [myComplaints, setMyComplaints] = useState([]);

  // Fetch user's complaints from the API
  useEffect(() => {
    const fetchMyComplaints = async () => {
      const userComplaints = await getComplaintsByStudent(user.id);
      setMyComplaints(userComplaints);
    };
    fetchMyComplaints();
  }, [user.id, getComplaintsByStudent]);

  const handleComplaintSubmit = () => {
    setSuccessMessage('✅ Complaint submitted successfully!');
    setActiveTab('view');
    setTimeout(() => setSuccessMessage(''), 3000);
  };

  const handleUpvote = async (complaintId) => {
    try {
      await upvoteComplaint(complaintId, user.id);
    } catch (error) {
      console.error('Error upvoting complaint:', error);
    }
  };

  return (
    <div className="dashboard">
      <div className="dashboard-header">
        <div>
          <h1>Student Portal</h1>
          <p>Welcome, {user.username}!</p>
        </div>
        <button className="logout-btn" onClick={onLogout}>
          Logout
        </button>
      </div>

      <div className="dashboard-content">
        {successMessage && (
          <div className="alert alert-success">{successMessage}</div>
        )}

        {/* Tabs */}
        <div style={{ marginBottom: '25px', borderBottom: '2px solid #FFE5CC' }}>
          <button
            style={{
              padding: '12px 20px',
              border: 'none',
              background: activeTab === 'submit' ? '#FF9F5A' : '#FFF8F3',
              color: activeTab === 'submit' ? 'white' : '#333',
              cursor: 'pointer',
              fontSize: '16px',
              fontWeight: '600',
              marginRight: '10px',
              borderRadius: '5px 5px 0 0',
              transition: 'all 0.3s',
            }}
            onClick={() => setActiveTab('submit')}
          >
            📝 Submit New Complaint
          </button>
          <button
            style={{
              padding: '12px 20px',
              border: 'none',
              background: activeTab === 'view' ? '#FF9F5A' : '#FFF8F3',
              color: activeTab === 'view' ? 'white' : '#333',
              cursor: 'pointer',
              fontSize: '16px',
              fontWeight: '600',
              borderRadius: '5px 5px 0 0',
              transition: 'all 0.3s',
            }}
            onClick={() => setActiveTab('view')}
          >
            📋 My Complaints ({myComplaints.length})
          </button>
        </div>

        {/* Submit Tab */}
        {activeTab === 'submit' && (
          <ComplaintForm
            studentId={user.id}
            userName={user.username}
            onSubmit={handleComplaintSubmit}
          />
        )}

        {/* View Tab */}
        {activeTab === 'view' && (
          <div>
            <h2 style={{ marginBottom: '20px', color: '#333' }}>My Complaints</h2>
            {myComplaints.length === 0 ? (
              <div className="empty-state">
                <h3>No complaints yet</h3>
                <p>Click on "Submit New Complaint" to report a maintenance issue</p>
              </div>
            ) : (
              <div className="complaints-container">
                {myComplaints.map((complaint) => (
                  <ComplaintCard
                    key={complaint._id}
                    complaint={complaint}
                    isMyComplaint={true}
                    onUpvote={() => handleUpvote(complaint._id)}
                    hasUpvoted={complaint.upvotedBy.includes(user.id)}
                  />
                ))}
              </div>
            )}
          </div>
        )}

        {/* All Complaints Tab (for upvoting) */}
        <div style={{ marginTop: '40px', paddingTop: '30px', borderTop: '2px solid #e0e0e0' }}>
          <h2 style={{ marginBottom: '20px', color: '#333' }}>
            All Complaints (Upvote to Show Urgency)
          </h2>
          {complaints.length === 0 ? (
            <div className="empty-state">
              <h3>No complaints in the system</h3>
              <p>Be the first to report an issue!</p>
            </div>
          ) : (
            <div className="complaints-container">
              {complaints
                .sort((a, b) => b.upvotes - a.upvotes)
                .map((complaint) => (
                  <ComplaintCard
                    key={complaint._id}
                    complaint={complaint}
                    isMyComplaint={complaint.userId === user.id}
                    onUpvote={() => handleUpvote(complaint._id)}
                    hasUpvoted={complaint.upvotedBy.includes(user.id)}
                  />
                ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default StudentDashboard;
