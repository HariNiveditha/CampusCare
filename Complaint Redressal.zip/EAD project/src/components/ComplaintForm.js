import React, { useState, useContext } from 'react';
import { ComplaintContext } from '../context/ComplaintContext';

const ComplaintForm = ({ studentId, userName, onSubmit }) => {
  const { addComplaint } = useContext(ComplaintContext);
  const [formData, setFormData] = useState({
    title: '',
    location: '',
    category: 'Electrical',
    description: '',
    photo: null,
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [photoPreview, setPhotoPreview] = useState(null);

  const categories = [
    'Electrical',
    'Plumbing',
    'Furniture',
    'Cleanliness',
    'Door/Lock',
    'Window',
    'Roads/Paths',
    'Common Areas',
    'Waste Management',
    'Other',
  ];

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handlePhotoChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      // Convert file to base64 for now
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData((prev) => ({
          ...prev,
          photo: reader.result,
        }));
        setPhotoPreview(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    // Validation
    if (!formData.title.trim()) {
      setError('Please enter a title');
      return;
    }
    if (!formData.description.trim()) {
      setError('Please describe the issue');
      return;
    }

    try {
      setLoading(true);
      // Add complaint
      await addComplaint({
        title: formData.title,
        description: formData.description,
        category: formData.category,
        userId: studentId,
        userName: userName,
      });

      // Reset form
      setFormData({
        title: '',
        location: '',
        category: 'Electrical',
        description: '',
        photo: null,
      });
      setPhotoPreview(null);

      // Notify parent
      onSubmit();
    } catch (err) {
      setError(err.message || 'Failed to submit complaint');
    } finally {
      setLoading(false);
    }
  };

  return (
    <form className="complaint-form" onSubmit={handleSubmit}>
      <h2>📝 Submit a New Complaint</h2>

      {error && <div className="alert alert-error">{error}</div>}

      <div className="form-row">
        <div className="form-group">
          <label htmlFor="title">Complaint Title *</label>
          <input
            id="title"
            type="text"
            name="title"
            placeholder="Brief title of your complaint"
            value={formData.title}
            onChange={handleInputChange}
            disabled={loading}
          />
        </div>

        <div className="form-group">
          <label htmlFor="location">Location (Optional)</label>
          <input
            id="location"
            type="text"
            name="location"
            placeholder="e.g., Room A-201, Corridor, Main Gate, Canteen"
            value={formData.location}
            onChange={handleInputChange}
            disabled={loading}
          />
        </div>
      </div>

      <div className="form-row">
        <div className="form-group">
          <label htmlFor="category">Category *</label>
          <select
            id="category"
            name="category"
            value={formData.category}
            onChange={handleInputChange}
            disabled={loading}
          >
            {categories.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>
        </div>
      </div>

      <div className="form-row full">
        <div className="form-group">
          <label htmlFor="description">Describe the Issue *</label>
          <textarea
            id="description"
            name="description"
            placeholder="Please describe the maintenance issue in detail..."
            rows="5"
            value={formData.description}
            onChange={handleInputChange}
            disabled={loading}
            style={{
              width: '100%',
              padding: '12px',
              border: '2px solid #FFE5CC',
              borderRadius: '5px',
              fontSize: '16px',
              fontFamily: 'inherit',
              resize: 'vertical',
            }}
          />
        </div>
      </div>

      <div className="form-row full">
        <div className="form-group">
          <label htmlFor="photo">Upload Photo (Optional)</label>
          <input
            id="photo"
            type="file"
            accept="image/*"
            onChange={handlePhotoChange}
            disabled={loading}
            style={{
              padding: '10px',
              border: '2px solid #FFE5CC',
              borderRadius: '5px',
            }}
          />
          {photoPreview && (
            <div
              style={{
                marginTop: '15px',
                borderRadius: '8px',
                overflow: 'hidden',
              }}
            >
              <img
                src={photoPreview}
                alt="Preview"
                style={{
                  width: '100%',
                  maxHeight: '200px',
                  objectFit: 'cover',
                  borderRadius: '8px',
                }}
              />
            </div>
          )}
        </div>
      </div>

      <button type="submit" className="complaint-form" style={{ width: 'auto' }} disabled={loading}>
        {loading ? 'Submitting...' : 'Submit Complaint'}
      </button>
    </form>
  );
};

export default ComplaintForm;
