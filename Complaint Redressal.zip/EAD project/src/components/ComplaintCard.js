import React, { useState } from 'react';

const ComplaintCard = ({
  complaint,
  isAdmin = false,
  isMyComplaint = false,
  onUpvote = null,
  onStatusChange = null,
  hasUpvoted = false,
}) => {
  const [newStatus, setNewStatus] = useState(complaint.status);
  const [adminResponse, setAdminResponse] = useState(complaint.adminResponse || '');
  const [showResponseInput, setShowResponseInput] = useState(false);

  const getUrgencyClass = (upvotes) => {
    if (upvotes >= 10) return 'critical';
    if (upvotes >= 5) return 'high';
    if (upvotes >= 2) return 'medium';
    return 'low';
  };

  const formatDate = (dateString) => {
    try {
      return new Date(dateString).toLocaleDateString('en-IN', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return dateString;
    }
  };

  // Support both old and new field names
  const complaintId = complaint._id || complaint.id;
  const complaintName = complaint.userName || complaint.studentName;
  const complaintTitle = complaint.title || complaint.location || 'Campus-wide Issue';

  const handleStatusUpdate = () => {
    if (onStatusChange) {
      onStatusChange(newStatus, adminResponse);
      setShowResponseInput(false);
    }
  };

  return (
    <div className={`complaint-card ${getUrgencyClass(complaint.upvotes)}`}>
      <div className="complaint-header">
        <div>
          <div className="complaint-id">#{complaintId}</div>
          <div style={{ marginTop: '10px' }}>
            <span className="complaint-category">{complaint.category}</span>
          </div>
        </div>
        <div className={`status-badge status-${complaint.status
          .toLowerCase()
          .replace(' ', '-')}`}>
          {complaint.status}
        </div>
      </div>

      <h3 className="complaint-title">
        {complaintTitle}
      </h3>

      <div className="complaint-details">
        <p>
          <strong>Reported by:</strong> {complaintName}
        </p>
        <p>
          <strong>Issue:</strong> {complaint.description}
        </p>
        <p>
          <strong>Date:</strong> {formatDate(complaint.createdAt)}
        </p>
      </div>

      {complaint.photo && (
        <img src={complaint.photo} alt="Issue" className="complaint-photo" />
      )}

      {complaint.adminResponse && (
        <div
          style={{
            marginTop: '15px',
            padding: '12px',
            background: '#E8F5E9',
            borderLeft: '4px solid #4CAF50',
            borderRadius: '5px',
            fontSize: '14px',
            color: '#2E7D32',
          }}
        >
          <strong>📌 Admin Response:</strong> {complaint.adminResponse}
        </div>
      )}

      <div className="complaint-footer">
        {isAdmin ? (
          <div className="status-update">
            <select
              value={newStatus}
              onChange={(e) => setNewStatus(e.target.value)}
              style={{ marginRight: '10px' }}
            >
              <option value="Pending">Pending</option>
              <option value="In Progress">In Progress</option>
              <option value="Resolved">Resolved</option>
            </select>
            <button onClick={() => setShowResponseInput(!showResponseInput)}>
              {showResponseInput ? 'Hide' : 'Add'} Response
            </button>
            <button onClick={handleStatusUpdate} style={{ marginLeft: '10px' }}>
              Update
            </button>
          </div>
        ) : (
          <div className="upvote-section">
            <button
              className={`upvote-btn ${hasUpvoted ? 'upvoted' : ''}`}
              onClick={onUpvote}
            >
              👍 Upvote
            </button>
            <span className="upvote-count">{complaint.upvotes}</span>
          </div>
        )}

        {!isAdmin && (
          <div className="upvote-section">
            <span style={{ fontSize: '12px', color: '#999' }}>
              {complaint.upvotes} upvotes
            </span>
          </div>
        )}
      </div>

      {showResponseInput && isAdmin && (
        <div style={{ marginTop: '15px' }}>
          <textarea
            placeholder="Enter admin response..."
            value={adminResponse}
            onChange={(e) => setAdminResponse(e.target.value)}
            style={{
              width: '100%',
              padding: '10px',
              border: '2px solid #FFE5CC',
              borderRadius: '5px',
              fontSize: '14px',
              fontFamily: 'inherit',
              minHeight: '80px',
              resize: 'vertical',
            }}
          />
        </div>
      )}

      {complaint.upvotes > 0 && (
        <div
          style={{
            marginTop: '10px',
            padding: '10px',
            background: '#FFF0E6',
            borderLeft: '4px solid #FF9F5A',
            borderRadius: '5px',
            fontSize: '12px',
            color: '#C85A1E',
            textAlign: 'center',
          }}
        >
          ⚡ {complaint.upvotes} student{complaint.upvotes !== 1 ? 's' : ''}{' '}
          experiencing this issue
        </div>
      )}
    </div>
  );
};

export default ComplaintCard;
