import React, { createContext, useState, useEffect, useCallback } from 'react';
import { complaintAPI } from '../api/api';

export const ComplaintContext = createContext();

export const ComplaintProvider = ({ children }) => {
  const [complaints, setComplaints] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Load complaints from backend on mount
  useEffect(() => {
    fetchAllComplaints();
  }, []);

  const fetchAllComplaints = async () => {
    try {
      setLoading(true);
      const response = await complaintAPI.getAllComplaints();
      setComplaints(response.data);
      setError(null);
    } catch (err) {
      console.error('Error fetching complaints:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const addComplaint = useCallback(async (complaintData) => {
    try {
      setLoading(true);
      const response = await complaintAPI.createComplaint(complaintData);
      setComplaints((prev) => [response.data, ...prev]);
      setError(null);
      return response.data._id;
    } catch (err) {
      console.error('Error creating complaint:', err);
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const updateComplaintStatus = useCallback(async (complaintId, newStatus, adminResponse = '') => {
    try {
      setLoading(true);
      const response = await complaintAPI.updateComplaintStatus(complaintId, newStatus, adminResponse);
      setComplaints((prev) =>
        prev.map((complaint) =>
          complaint._id === complaintId ? response.data : complaint
        )
      );
      setError(null);
    } catch (err) {
      console.error('Error updating complaint:', err);
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const upvoteComplaint = useCallback(async (complaintId, userId) => {
    try {
      const response = await complaintAPI.upvoteComplaint(complaintId, userId);
      setComplaints((prev) =>
        prev.map((complaint) =>
          complaint._id === complaintId ? response.data : complaint
        )
      );
      setError(null);
    } catch (err) {
      console.error('Error upvoting complaint:', err);
      setError(err.message);
      throw err;
    }
  }, []);

  const deleteComplaint = useCallback(async (complaintId) => {
    try {
      setLoading(true);
      await complaintAPI.deleteComplaint(complaintId);
      setComplaints((prev) =>
        prev.filter((complaint) => complaint._id !== complaintId)
      );
      setError(null);
    } catch (err) {
      console.error('Error deleting complaint:', err);
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const getComplaintsByStudent = useCallback(async (studentId) => {
    try {
      const response = await complaintAPI.getComplaintsByUser(studentId);
      return response.data;
    } catch (err) {
      console.error('Error fetching student complaints:', err);
      setError(err.message);
      return [];
    }
  }, []);

  const getComplaintsByStatus = useCallback((status) => {
    return complaints.filter((complaint) => complaint.status === status);
  }, [complaints]);

  const getComplaintsByCategory = useCallback((category) => {
    return complaints.filter((complaint) => complaint.category === category);
  }, [complaints]);

  const value = {
    complaints,
    loading,
    error,
    addComplaint,
    updateComplaintStatus,
    upvoteComplaint,
    deleteComplaint,
    getComplaintsByStudent,
    getComplaintsByStatus,
    getComplaintsByCategory,
    fetchAllComplaints,
  };

  return (
    <ComplaintContext.Provider value={value}>
      {children}
    </ComplaintContext.Provider>
  );
};
