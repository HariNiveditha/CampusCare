import axios from 'axios';

const API_BASE_URL = 'http://localhost:5000/api';

const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add token to requests if it exists
apiClient.interceptors.request.use((config) => {
  const token = localStorage.getItem('authToken');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Auth APIs
export const authAPI = {
  login: (username, password) =>
    apiClient.post('/auth/login', { username, password }),
  register: (username, email, password, confirmPassword) =>
    apiClient.post('/auth/register', { username, email, password, confirmPassword }),
};

// Complaint APIs
export const complaintAPI = {
  createComplaint: (complaintData) =>
    apiClient.post('/complaints', complaintData),
  getAllComplaints: () =>
    apiClient.get('/complaints'),
  getComplaintsByUser: (userId) =>
    apiClient.get(`/complaints/user/${userId}`),
  updateComplaintStatus: (complaintId, status, adminResponse) =>
    apiClient.put(`/complaints/${complaintId}`, { status, adminResponse }),
  upvoteComplaint: (complaintId, userId) =>
    apiClient.post(`/complaints/${complaintId}/upvote`, { userId }),
  deleteComplaint: (complaintId) =>
    apiClient.delete(`/complaints/${complaintId}`),
};

export default apiClient;
