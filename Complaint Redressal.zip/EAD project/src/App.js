import React, { useState, useEffect } from 'react';
import './App.css';
import Login from './components/Login';
import StudentDashboard from './components/StudentDashboard';
import AdminDashboard from './components/AdminDashboard';
import { ComplaintProvider } from './context/ComplaintContext';

function App() {
  const [user, setUser] = useState(null);
  const [role, setRole] = useState(null);

  useEffect(() => {
    const savedUser = localStorage.getItem('currentUser');
    const savedRole = localStorage.getItem('userRole');
    if (savedUser) {
      try {
        setUser(JSON.parse(savedUser));
        setRole(savedRole);
      } catch (error) {
        console.error('Error loading user from storage:', error);
      }
    }
  }, []);

  const handleLogin = (userData, userRole) => {
    setUser(userData);
    setRole(userRole);
    localStorage.setItem('currentUser', JSON.stringify(userData));
    localStorage.setItem('userRole', userRole);
  };

  const handleLogout = () => {
    setUser(null);
    setRole(null);
    localStorage.removeItem('currentUser');
    localStorage.removeItem('userRole');
  };

  return (
    <ComplaintProvider>
      <div className="app">
        {!user ? (
          <Login onLogin={handleLogin} />
        ) : role === 'admin' ? (
          <AdminDashboard user={user} onLogout={handleLogout} />
        ) : (
          <StudentDashboard user={user} onLogout={handleLogout} />
        )}
      </div>
    </ComplaintProvider>
  );
}

export default App;
