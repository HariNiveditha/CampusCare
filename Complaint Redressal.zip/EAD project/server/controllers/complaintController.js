const Complaint = require('../models/Complaint');

// Create complaint
exports.createComplaint = async (req, res) => {
  try {
    const { title, description, category, userId, userName } = req.body;

    if (!title || !description || !category || !userId || !userName) {
      return res.status(400).json({ message: 'All fields are required' });
    }

    const newComplaint = new Complaint({
      title,
      description,
      category,
      userId,
      userName,
    });

    await newComplaint.save();
    res.status(201).json(newComplaint);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Get all complaints
exports.getAllComplaints = async (req, res) => {
  try {
    const complaints = await Complaint.find().sort({ createdAt: -1 });
    res.json(complaints);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Get complaints by user
exports.getComplaintsByUser = async (req, res) => {
  try {
    const { userId } = req.params;
    const complaints = await Complaint.find({ userId }).sort({ createdAt: -1 });
    res.json(complaints);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Update complaint status and add admin response
exports.updateComplaintStatus = async (req, res) => {
  try {
    const { complaintId } = req.params;
    const { status, adminResponse } = req.body;

    if (!status) {
      return res.status(400).json({ message: 'Status is required' });
    }

    const updatedComplaint = await Complaint.findByIdAndUpdate(
      complaintId,
      { 
        status, 
        adminResponse: adminResponse || '',
        updatedAt: Date.now() 
      },
      { new: true }
    );

    if (!updatedComplaint) {
      return res.status(404).json({ message: 'Complaint not found' });
    }

    res.json(updatedComplaint);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Upvote complaint
exports.upvoteComplaint = async (req, res) => {
  try {
    const { complaintId } = req.params;
    const { userId } = req.body;

    const complaint = await Complaint.findById(complaintId);
    if (!complaint) {
      return res.status(404).json({ message: 'Complaint not found' });
    }

    const alreadyUpvoted = complaint.upvotedBy.includes(userId);

    if (alreadyUpvoted) {
      // Remove upvote
      complaint.upvotedBy = complaint.upvotedBy.filter((id) => id.toString() !== userId);
      complaint.upvotes = Math.max(0, complaint.upvotes - 1);
    } else {
      // Add upvote
      complaint.upvotedBy.push(userId);
      complaint.upvotes += 1;
    }

    await complaint.save();
    res.json(complaint);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Delete complaint
exports.deleteComplaint = async (req, res) => {
  try {
    const { complaintId } = req.params;

    const deletedComplaint = await Complaint.findByIdAndDelete(complaintId);

    if (!deletedComplaint) {
      return res.status(404).json({ message: 'Complaint not found' });
    }

    res.json({ message: 'Complaint deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};
