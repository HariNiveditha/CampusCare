const mongoose = require('mongoose');
const dotenv = require('dotenv');
const User = require('../models/User');
const Complaint = require('../models/Complaint');

dotenv.config();

const seedDatabase = async () => {
  try {
    // Connect to MongoDB using direct connection (no SRV DNS lookup)
    const mongoUri = process.env.MONGODB_URI || 'mongodb://harini_db_user:nivi%261202@cluster0-shard-00-00.oicr31g.mongodb.net:27017,cluster0-shard-00-01.oicr31g.mongodb.net:27017,cluster0-shard-00-02.oicr31g.mongodb.net:27017/complaint-redressal-system?replicaSet=atlas-11jxj0-shard-0&retryWrites=true&w=majority';
    await mongoose.connect(mongoUri, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      serverSelectionTimeoutMS: 10000,
      connectTimeoutMS: 10000,
    });
    console.log('Connected to MongoDB');

    // Clear existing data
    await User.deleteMany({});
    await Complaint.deleteMany({});
    console.log('Cleared existing data');

    // Create demo users (passwords will be hashed by pre-save middleware)
    const users = await User.create([
      {
        username: 'admin',
        email: 'admin@college.edu',
        password: 'admin123',
        role: 'admin',
      },
      {
        username: 'student',
        email: 'student@college.edu',
        password: 'student123',
        role: 'student',
      },
      {
        username: 'john_doe',
        email: 'john@college.edu',
        password: 'john123',
        role: 'student',
      },
    ]);
    console.log(`Created ${users.length} demo users`);

    // Create demo complaints
    const complaints = await Complaint.create([
      {
        title: 'Broken Light in Room 101',
        description: 'The light bulb in room 101 is broken and needs replacement',
        category: 'Electrical',
        userId: users[1]._id,
        userName: users[1].username,
        status: 'Pending',
        upvotes: 3,
        upvotedBy: [users[2]._id],
      },
      {
        title: 'Leaky Tap in Bathroom',
        description: 'There is a continuous leak from the tap in the main bathroom',
        category: 'Plumbing',
        userId: users[2]._id,
        userName: users[2].username,
        status: 'In Progress',
        upvotes: 5,
        upvotedBy: [users[1]._id, users[2]._id],
        adminResponse: 'Maintenance team has been notified. Expected completion by tomorrow.',
      },
      {
        title: 'Broken Window Latch',
        description: 'The window in the common area cannot be properly locked',
        category: 'Window',
        userId: users[1]._id,
        userName: users[1].username,
        status: 'Resolved',
        upvotes: 2,
        upvotedBy: [],
        adminResponse: 'Window has been repaired and tested successfully.',
      },
    ]);
    console.log(`Created ${complaints.length} demo complaints`);

    console.log('Database seeding completed successfully!');
    console.log('\nDemo Credentials:');
    console.log('- Admin: username=admin, password=admin123');
    console.log('- Student: username=student, password=student123');
    console.log('- Student: username=john_doe, password=john123');
    process.exit(0);
  } catch (error) {
    console.error('Error seeding database:', error);
    process.exit(1);
  }
};

seedDatabase();
