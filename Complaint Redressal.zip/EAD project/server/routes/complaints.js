const express = require('express');
const router = express.Router();
const complaintController = require('../controllers/complaintController');

router.post('/', complaintController.createComplaint);
router.get('/', complaintController.getAllComplaints);
router.get('/user/:userId', complaintController.getComplaintsByUser);
router.put('/:complaintId', complaintController.updateComplaintStatus);
router.post('/:complaintId/upvote', complaintController.upvoteComplaint);
router.delete('/:complaintId', complaintController.deleteComplaint);

module.exports = router;
