# College Complaint Redressal System

A web application for hostel students and administrators to report, track, and manage maintenance complaints with MongoDB backend.

## 🎯 Features

### Student Features
- **Submit Complaints**: Report maintenance issues with category, description, and location
- **View My Complaints**: Track all submitted complaints with current status
- **Upvote System**: Upvote other complaints to show urgency
- **Status Tracking**: Real-time status updates (Pending → In Progress → Resolved)

### Admin Features
- **Dashboard**: Overview with complaint statistics
- **Filter & Search**: Filter by status, category, or search by title/student name
- **Status Management**: Update complaint status with admin response
- **Prioritization**: Complaints sorted by upvotes to identify urgent issues

## 🔧 Tech Stack

- **Frontend**: React 18, Axios
- **Backend**: Node.js, Express.js
- **Database**: MongoDB
- **State Management**: Context API
- **Styling**: CSS3

## 📦 Installation & Setup

### Prerequisites
- Node.js (v14 or higher)
- npm or yarn
- MongoDB (local or Atlas)

### Frontend Setup

1. Navigate to project root:
```bash
cd "EAD project"
```

2. Install frontend dependencies:
```bash
npm install
```

3. Start the frontend development server:
```bash
npm start
```

Frontend will run on `http://localhost:3000`

### Backend Setup

1. Navigate to server directory:
```bash
cd server
```

2. Install backend dependencies:
```bash
npm install
```

3. Create `.env` file with MongoDB connection:
```env
MONGODB_URI=mongodb://localhost:27017/complaint-redressal-system
PORT=5000
NODE_ENV=development
```

4. Seed database with demo data:
```bash
node scripts/seedDatabase.js
```

Demo Credentials:
- Admin: `admin` / `admin123`
- Student: `student` / `student123`
- Student: `john_doe` / `john123`

5. Start the backend server:
```bash
npm start
# or for development:
npm run dev
```

Backend will run on `http://localhost:5000`

### Running Both Servers

Open two terminals:

**Terminal 1 (Frontend)**:
```bash
npm start
```

**Terminal 2 (Backend)**:
```bash
cd server
npm start
```

Then open `http://localhost:3000` in your browser.

## 📚 API Documentation

See [server/README.md](server/README.md) for detailed API endpoints and database schema.

## 📋 Usage

1. **Login**: Use demo credentials or create a new account
2. **Submit Complaint**: Click "Submit New Complaint" and fill in details
3. **View Status**: Check complaint status in "My Complaints" tab
4. **Upvote**: Support other complaints by upvoting them
5. **Admin View**: Login as admin to manage all complaints

## 🚀 Deployment

- Frontend can be deployed to Vercel, Netlify, or GitHub Pages
- Backend can be deployed to Heroku, Railway, or any Node.js hosting
- Remember to update the proxy URL in frontend `package.json` for production

## 📝 Notes

- Passwords are stored in plain text for demo purposes only
- In production, implement bcrypt for password hashing
- Add JWT authentication for better security
- Implement file upload for complaint photos


## 🚀 Usage

### For Students
1. Login with your name and select "Student" role
2. Click "Submit New Complaint" to report issues
3. View all complaints and upvote others to show urgency
4. Track your complaints in "My Complaints" tab

### For Admins
1. Login with admin credentials and select "Admin/Warden" role
2. View dashboard with complaint statistics
3. Use filters to find specific complaints
4. Update complaint status as you address them
5. Sort by upvotes to identify urgent issues

## 💾 Data Persistence

All data is stored in browser's LocalStorage:
- Complaints persist across browser sessions
- Upvotes are tracked per user
- No backend server required for this version

## 🔐 Demo Credentials

Since this is a demo version:
- **Any username works** (no authentication needed)
- Switch between Student and Admin roles easily
- Demo data persists in LocalStorage

## 📊 Database Structure (MongoDB - Future Backend)

```javascript
{
  complaints: [
    {
      id: Number,
      studentId: Number,
      studentName: String,
      location: String,      // Room, corridor, building, etc. (optional)
      category: String,      // Electrical, Plumbing, Furniture, etc.
      description: String,
      photo: String,         // Base64 encoded image
      status: String,        // Pending, In Progress, Resolved
      upvotes: Number,
      upvotedBy: [Number],
      createdAt: Date
    }
  ]
}
```

## 🎨 Categories

- Electrical
- Plumbing
- Furniture
- Cleanliness
- Door/Lock
- Window
- Roads/Paths
- Common Areas
- Waste Management
- Other

## 🏗️ Project Structure

```
src/
├── components/
│   ├── Login.js              # Login page with role selection
│   ├── StudentDashboard.js   # Student portal
│   ├── AdminDashboard.js     # Admin portal
│   ├── ComplaintForm.js      # Complaint submission form
│   └── ComplaintCard.js      # Complaint display card
├── context/
│   └── ComplaintContext.js   # Global state management
├── App.js                    # Main app component
└── App.css                   # Global styles
```

## 🔄 State Management

Uses React Context API for:
- Complaint CRUD operations
- Global complaint list
- Upvote system
- LocalStorage persistence

## 🎓 Course Project Notes

This is a simplified version suitable for course submission:
- No authentication/authorization
- Uses LocalStorage instead of database
- Single-file components for clarity
- Clean, maintainable code structure
- Responsive design for mobile & desktop

## 🚀 Future Enhancements

- Node.js/Express backend
- MongoDB database integration
- JWT authentication
- Image upload to cloud storage
- Email notifications
- Real-time updates with WebSockets
- Admin dashboard charts
- Complaint categories management

## 📝 Notes

- LocalStorage data can be cleared in browser DevTools
- Each browser has separate data storage
- For production, implement proper backend API
- Consider adding image compression for better performance

## 👨‍💻 Author

Created as a course project for college complaint management system.

## 📄 License

This project is free to use for educational purposes.
